#include "Utilities.h"

#include <iostream>

HANDLE Utilities::hConsole;