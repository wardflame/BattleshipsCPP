#include "SubmarineShip.h"

SubmarineShip::SubmarineShip() : Ship(ShipType::Submarine, 3)
{
}
