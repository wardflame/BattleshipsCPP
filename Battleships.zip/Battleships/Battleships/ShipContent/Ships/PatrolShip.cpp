#include "PatrolShip.h"

PatrolShip::PatrolShip() : Ship(ShipType::Patrol, 2)
{
}
