#pragma once
#include "../Ship.h"

class SubmarineShip : public Ship
{
public:
	SubmarineShip();
};