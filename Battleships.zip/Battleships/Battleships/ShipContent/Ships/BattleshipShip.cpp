#include "BattleshipShip.h"

BattleShipShip::BattleShipShip() : Ship(ShipType::Battleship, 4)
{
}
