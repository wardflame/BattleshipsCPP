#pragma once
#include "../Ship.h"

class DestroyerShip : public Ship
{
public:
	DestroyerShip();
};