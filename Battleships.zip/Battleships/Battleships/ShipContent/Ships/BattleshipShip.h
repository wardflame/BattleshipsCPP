#pragma once
#include "../Ship.h"

class BattleShipShip : public Ship
{
public:
	BattleShipShip();
};