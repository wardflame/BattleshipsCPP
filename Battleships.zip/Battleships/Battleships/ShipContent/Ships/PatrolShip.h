#pragma once
#include "../Ship.h"

class PatrolShip : public Ship
{
public:
	PatrolShip();
};