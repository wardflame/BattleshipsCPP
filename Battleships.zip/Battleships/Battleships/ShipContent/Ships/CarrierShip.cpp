#include "CarrierShip.h"

CarrierShip::CarrierShip() : Ship(ShipType::Carrier, 5)
{
}
