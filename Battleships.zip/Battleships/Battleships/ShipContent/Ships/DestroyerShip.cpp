#include "DestroyerShip.h"

DestroyerShip::DestroyerShip() : Ship(ShipType::Destroyer, 3)
{
}
