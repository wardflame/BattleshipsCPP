#pragma once
#include "../Ship.h"

class CarrierShip : public Ship
{
public:
	CarrierShip();
};